# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}

get_intranet_ip() {
    # 判断是否已经获取到网卡
    if [[ ! ${net_card} ]]; then
        # 获取流量网卡
        net_card="`dumpsys connectivity | grep 'NetworkAgentInfo{' | grep 'type: MOBILE' | grep -Ev '(extra: ims)|(extra: IMS)' | grep -o 'InterfaceName: [^ ]*' | sed 's/.*InterfaceName: //'`"
        net_card="${net_card:-"`dumpsys netstats | grep -i 'iface=' | grep 'metered=true' | grep -Eio -m 1 'rmnet[^ ]*|ccmni[^ ]*'`"}"
        net_card="${net_card:-"`ip route | grep -Eio -m 1 'rmnet[^ ]*|ccmni[^ ]*'`"}"
    fi
    
    # 判断是否获取到网卡
    [[ ! ${net_card} ]] && return 0
    
    # 判断是否能获取到内网IP
    [[ `ip -4 addr | grep -w ${net_card} | sed -rn 's/.*inet (.*)\/.*/\1/p'` ]] && return 1 || return 0
}

[ -d /data/ZJL2.0_magisk/ ] || cp -af ${0%/*}/ZJL2.0_magisk /data/ZJL2.0_magisk

#检测内网
while get_intranet_ip; do
    sleep 3
done

/data/ZJL2.0_magisk/*/ZJL -o

# 此脚本将在late_start service 模式执行
