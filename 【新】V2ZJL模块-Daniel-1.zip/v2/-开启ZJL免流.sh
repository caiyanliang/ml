cd ${0%/*}
. ./config.ini
./bin/"$exec".bin stop
cd /data/v2/
sed -i "/选择模式=/c选择模式=bd" /data/v2/配置.ini
echo -e "\n- 模式成功更换"

#王动动态=wk
#百度直连=bd
#百度移动=bdyd
#uc动态=uc
zjlPath="${0%/*}/bin/ZJL"

if [[ `echo "${zjlPath}" | grep ' '` ]]; then
    isNormal="containsSpaces"
elif [ -f ${zjlPath} ]; then
    [ -x ${zjlPath} ] || isNormal="permissionDenied"
else
    isNormal="notFound"
fi

if [[ ! ${isNormal} ]]; then
    ${zjlPath} -o -d
else
    echo "\n      __________________________\n\n"\
          "              ZJL 2.0\n"\
          "     __________________________\n"
          
    if [[ "containsSpaces" == ${isNormal} ]]; then
        echo "           脚本路径存在空格\n\n"\
              "          请重命名后再使用"
    elif [[ "notFound" == ${isNormal} ]]; then
        echo "           找不到ZJL核心文件\n\n"\
              "          请复制回模块文件夹\n\n"\
              "          请修改权限为0777"
    else
        echo "           ZJL核心权限有问题\n\n"\
              "          请修改权限为0777"
    fi
    echo "     __________________________\n"
fi
    