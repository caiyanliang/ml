/system/bin/sh /data/v2/*/ZJL -c
#!/system/bin/sh
cd /data/v2
         

DIR="${0%/*}"/bin/busybox
 v2=`$DIR cut -d '/' -f 3 ./*.txt`
 test=$($DIR printf "%s" $v2| $DIR base64 -d)
 echo "$test" > ./输出.ini
 ip=`$DIR cut -d '"' -f 4 ./输出.ini` #ip
 port=`$DIR cut -d '"' -f 28 ./输出.ini` #接口
 uuid=`$DIR cut -d '"' -f 16 ./输出.ini` #uuid
 alterld=`$DIR cut -d '"' -f 8 ./输出.ini` #额外id
 network=`$DIR cut -d '"' -f 20 ./输出.ini` #传输协议
 path=`$DIR cut -d '"' -f 24 ./输出.ini` #path
 tsoh=`$DIR cut -d '"' -f 12 ./输出.ini` #tsoh

host=跟随节点
 if [[ "tcp" == ${network} ]]; then
 network=GET
 fi 
 echo "- 节点成功转换"          
echo -e "addr="$ip:$port"\nuuid="$uuid"\nalterId=$alterld\nsecurity="auto"\nmethod="$network"\npath="$path"\nhost="$tsoh"\nDNS="223.6.6.6"" >./config/Daniel.ini         
rm -f ./*.bak
rm -f ./输出.ini
rm -f ./输出1.ini
cd /data/v2/
sed -i "/file=/cfile=Daniel" /data/v2/config.ini
echo -e "\n- 模式成功更换"

cd ${0%/*}
. ./config.ini
./bin/"$exec".bin start
/system/bin/sh /data/v2/*/ZJL -d